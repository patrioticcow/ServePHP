chrome.devtools.panels.create("ServePHP",
    "icon-128.png",
    "panel.html",
    function(panel) {

    }
);